<p <label for="matkhaucu">Mat khau cu:</label>
    <input value="<?php if(isset($matkhaucu)==true) echo $matkhaucu; ?>"type="password" class="form=control" name="matkhaucu" id="matkhaucu">
</p>
<p <label for="matkhaumoi_1">Mat khau moi:</label>
    <input value="<?php if(isset($matkhaumoi_1)==true) echo $matkhaumoi_1; ?>"type="password" class="form=control" name="matkhaumoi_1" id="matkhaumoi_1">
</p>
<p <label for="matkhaumoi_2">Nhap lai mat khau moi:</label>
    <input value="<?php if(isset($matkhaumoi_2)==true) echo $matkhaumoi_2; ?>"type="password" class="form=control" name="matkhaumoi_2" id="matkhaumoi_2">
</p>
<p><button type="submit" name="btndoimatkhau" value="doimatkhau" class="btn btn-warning">Doi mat khau</button></p>
</form>
</div>
</div>


