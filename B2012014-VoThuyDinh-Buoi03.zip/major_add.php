<!DOCTYPE HTML>
<html>  
<body>

<form action="major_edit_save.php" method="post">
Name: <input type="text" name="name"><br>
<input type="submit">
</form>

</body>
</html>